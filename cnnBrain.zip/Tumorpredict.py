#!/usr/bin/env python
# coding: utf-8

# In[2]:


from keras.models import load_model 
classifier = load_model('cnnBrain.h5')
import numpy as np
from keras.models import load_model
from keras.preprocessing import image
from keras.preprocessing.image import ImageDataGenerator,array_to_img,img_to_array,load_img
image_to_predict = '/content/Brain/test/no/no 9.png'
test_image =image.load_img(image_to_predict,target_size =(64,64))
test_image =image.img_to_array(test_image)
test_image =np.expand_dims(test_image, axis =0)
result = classifier.predict(test_image)
if result[0][0] >= 0.7:
    prediction = 'tumour'
else:
    prediction = 'non tumor'
print(prediction)

